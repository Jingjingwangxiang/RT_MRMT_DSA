clear all; clc; close all; 

set(0, 'defaultfigurecolor', 'w');

load('cm_silva.mat'); 
load('cm_proposed_method.mat');

figure; 
loglog(cm_silva, 'linewidth', 4);
hold on; 
loglog([2:2:1000], cm_proposed_method(2:2:1000), 's', 'markersize', 6, 'linewidth', 3);
grid on; 
xlim([10^(0) 10^(5)]); ylim([10^(-16) 10^(0)]);
set(gca, 'Linewidth', 1, 'Fontweight', 'bold', 'Fontsize', 20);
legend('Silva et al., 2009 (numerical)', 'proposed method (numerical)');
xlabel('t');
ylabel('c');