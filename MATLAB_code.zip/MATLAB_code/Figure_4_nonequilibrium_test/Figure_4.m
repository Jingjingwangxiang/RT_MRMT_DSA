close all; clear all; clc; 

set(0, 'defaultfigurecolor', 'w');

L = 100; 
porosity_im_j = 0.1;
porosity_m = 0.1;
q_Darcy = 1.0;
v = q_Darcy / porosity_m; 
alpha_L = 1.0; 
L_c = alpha_L; 
t_c = L_c / v; 
D = alpha_L * v; 
eta = porosity_im_j/porosity_m; 

x = 100;
x_D = x/L_c;
t = [1:1:1000];
t_D = t/t_c; 

% Gamma probability density function of mass exchange rates 
alpha = [[0.0001:0.0001:0.001], [0.002:0.001:0.01], [0.02:0.01:0.1], [0.2:0.1:1], [2:1:10], [20:10:100]];
beta = 1/2; alpha_0 = 10^(1);
f_alpha = gampdf(alpha, beta, alpha_0); 

% Gamma cumulative distribution function
prob = gamcdf(alpha, beta, alpha_0);
p_alpha = gradient(prob); sum(p_alpha)

pj = p_alpha; 
alpha_j_D = alpha * t_c;

k = 0.01; 
k_D = k*t_c; 

lamda_j_D = alpha_j_D + k_D; 
pj = p_alpha; 

u = 1.0; 

um_D = euler_inversion(@(s)  u ./s * exp(x_D/2) .* exp(-x_D/2*sqrt(1+4*(s+k_D).*(1+eta.* sum( alpha_j_D .* pj ./ (s + lamda_j_D) )))), t_D);
uim_j_D = zeros(size(t, 2), size(alpha_j_D, 2));
for j = 1:size(alpha_j_D, 2)
    j
    uim_j_D(:, j) = euler_inversion(@(s)  u ./s * exp(x_D/2) .* exp(-x_D/2*sqrt(1+4*(s+k_D).*(1+eta.* sum( alpha_j_D .* pj ./ (s + lamda_j_D) ))))  .*  (alpha_j_D(j) ./ (s + lamda_j_D(j))), t_D);
end 
sum_uim_j_D = zeros(size(t, 2), 1);
for j = 1:size(alpha_j_D, 2)
    sum_uim_j_D = sum_uim_j_D + pj(j) * uim_j_D(:, j) ; 
end 

rk_tot_m_D = k_D * um_D; 
rk_tot_m = rk_tot_m_D / t_c; 
rk_tot_im_j_D = zeros(size(t, 2), size(alpha_j_D, 2));
for j = 1:size(alpha_j_D, 2)
    rk_tot_im_j_D(:, j) = k_D * uim_j_D(:, j);
end 
sum_rk_tot_im_j_D = zeros(size(t, 2), 1);
for j = 1:size(alpha_j_D, 2)
    sum_rk_tot_im_j_D = sum_rk_tot_im_j_D + pj(j) * rk_tot_im_j_D(:, j) ; 
end 
sum_rk_tot_im_j = sum_rk_tot_im_j_D / t_c; 

figure; 
semilogx(t, um_D, 'Linewidth', 4); 
hold on; 
load('um_simulated.mat'); 
semilogx(t, um_simulated, 'o', 'markersize', 10, 'Linewidth', 3);
semilogx(t, sum_uim_j_D, 'Linewidth', 4);
load('uim_simulated.mat'); 
semilogx(t, uim_simulated, 'o', 'markersize', 10, 'Linewidth', 3);
xlim([10^(0) 10^(3)])
set(gca, 'Linewidth', 1, 'Fontweight', 'bold', 'Fontsize', 28);
legend('u_{m} (analytical)', 'u_{m} (numerical)', 'u_{im} (analytical)', 'u_{im} (numerical)');
xlabel('t');
ylabel('u');

figure; 
semilogx(t, rk_tot_m, 'Linewidth', 4); 
hold on; 
load('rkm_simulated.mat'); 
semilogx(t, rkm_simulated, 'o', 'markersize', 10, 'Linewidth', 3);
semilogx(t, sum_rk_tot_im_j, 'Linewidth', 4);
load('rkim_simulated.mat'); 
semilogx(t, rkim_simulated, 'o', 'markersize', 10, 'Linewidth', 3);
xlim([10^(0) 10^(3)])
set(gca, 'Linewidth', 1, 'Fontweight', 'bold', 'Fontsize', 28);
legend('r_{km} (analytical)', 'r_{km} (numerical)', 'r_{kim} (analytical)', 'r_{kim} (numerical)');
xlabel('t');
ylabel('r_{k}'); 
