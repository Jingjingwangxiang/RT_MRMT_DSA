close all; clear all; clc; 

number_immobile_zones = [1 3 5 7 10];
CPU_time = [232.3125  342.0000; 665.1719 769.5938; 1405.4375 1111.2031; 2606.8750 1495.8125; 5766.6875 2027.8125];

set(0, 'defaultfigurecolor', 'w');
figure; 
bar(number_immobile_zones, CPU_time);
set(gca, 'Linewidth', 2, 'Fontweight', 'bold', 'Fontsize', 20);
xlabel('Number of immobile zones');
ylabel('CPU time (s)');
ytickformat('%.1E');

CPU_time = [4033.2344  1414.8906; 16897.5938 5066.4688; 59203.1094 12841.5781];
set(0, 'defaultfigurecolor', 'w');
figure; 
bar(CPU_time);
set(gca, 'Linewidth', 2, 'Fontweight', 'bold', 'Fontsize', 20);
xlabel('Chemical system');
ylabel('CPU time (s)');
ytickformat('%.1E');