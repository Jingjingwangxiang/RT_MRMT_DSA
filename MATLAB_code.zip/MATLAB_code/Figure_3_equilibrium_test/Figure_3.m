close all; clear all; clc; 

set(0, 'defaultfigurecolor', 'w');

L = 100; 
porosity_im_j = 0.1;
porosity_m = 0.1;
q_Darcy = 1.0;
v = q_Darcy / porosity_m; 
alpha_L = 1.0; 
L_c = alpha_L; 
t_c = L_c / v; 
D = alpha_L * v; 
eta = porosity_im_j/porosity_m; 

K = 10^(-4.4823);

x = 100;
x_D = x/L_c;
t = [0.1:0.1:1000];
t_D = t/t_c; 

% Gamma probability density function of mass exchange rates 
alpha = [[0.0001:0.0001:0.001], [0.002:0.001:0.01], [0.02:0.01:0.1], [0.2:0.1:1], [2:1:10], [20:10:100]];
beta = 1/2; alpha_0 = 10^(1);
f_alpha = gampdf(alpha, beta, alpha_0); 

% Gamma cumulative distribution function
prob = gamcdf(alpha, beta, alpha_0);
p_alpha = gradient(prob); sum(p_alpha)

pj = p_alpha; 
alpha_j_D = alpha * t_c;

u = 1.0; 

um_D = euler_inversion(@(s)  u ./s * exp(x_D/2) .* exp(-x_D/2*sqrt(1+4*s.*(1+eta.* sum( alpha_j_D .* pj ./ (s + alpha_j_D) )))), t_D);
dum_dx_D = euler_inversion(@(s)  u ./s * exp(x_D/2) .* exp(-x_D/2*sqrt(1+4*s.*(1+eta.* sum( alpha_j_D .* pj ./ (s + alpha_j_D) ))))  .* (1/2) .* ( 1 - sqrt(1+4*s.*(1+eta.* sum( alpha_j_D .* pj ./ (s + alpha_j_D) ))) ) , t_D); 

uim_j_D = zeros(size(t, 2), size(alpha_j_D, 2));
duim_j_dt_D = zeros(size(t, 2), size(alpha_j_D, 2));
for j = 1:size(alpha_j_D, 2)
    j
    uim_j_D(:, j) = euler_inversion(@(s)  u ./s * exp(x_D/2) .* exp(-x_D/2*sqrt(1+4*s.*(1+eta.* sum( alpha_j_D .* pj ./ (s + alpha_j_D) ))))  .*  (alpha_j_D(j) ./ (s + alpha_j_D(j))), t_D);
    duim_j_dt_D(:, j) = ( alpha_j_D(j) * um_D + euler_inversion(@(s)  u ./s * exp(x_D/2) .* exp(-x_D/2*sqrt(1+4*s.*(1+eta.* sum( alpha_j_D .* pj ./ (s + alpha_j_D) )))) .* (- alpha_j_D(j)^2/(alpha_j_D(j)+s)), t_D) );
end 
sum_uim_j_D = zeros(size(t, 2), 1);
for j = 1:size(alpha_j_D, 2)
    sum_uim_j_D = sum_uim_j_D + pj(j) * uim_j_D(:, j) ; 
end 

c1m_D = ( um_D + sqrt(um_D.^2 + 4*K) ) / 2; 
c2m_D = ( - um_D + sqrt(um_D.^2 + 4*K) ) / 2; 
dc2m_dum_D = 1/2 * ( -1 + um_D ./ sqrt(um_D.^2 + 4*K) ); 
c1im_j_D = zeros(size(t, 2), size(alpha_j_D, 2));
c2im_j_D = zeros(size(t, 2), size(alpha_j_D, 2));
dc2im_j_duim_j_D = zeros(size(t, 2), size(alpha_j_D, 2));
for j = 1:size(alpha_j_D, 2)
    c1im_j_D(:, j) = ( uim_j_D(:, j) + sqrt(uim_j_D(:, j).^2 + 4*K) ) / 2; 
    c2im_j_D(:, j) = ( - uim_j_D(:, j) + sqrt(uim_j_D(:, j).^2 + 4*K) ) / 2; 
    dc2im_j_duim_j_D(:, j) = (1/2)*(-1+uim_j_D(:, j)./sqrt(uim_j_D(:, j).^2+4*K)); 
end 
sum_c1im_j_D = zeros(size(t, 2), 1);
for j = 1:size(alpha_j_D, 2)
    sum_c1im_j_D = sum_c1im_j_D + pj(j) * c1im_j_D(:, j) ; 
end 
sum_c2im_j_D = zeros(size(t, 2), 1);
for j = 1:size(alpha_j_D, 2)
    sum_c2im_j_D = sum_c2im_j_D + pj(j) * c2im_j_D(:, j) ; 
end 

% ========================= Analytical Solution =========================
% ------------------------- r_im ------------------------- 
reim_j_D = zeros(size(t, 2), size(alpha_j_D, 2));
for j = 1:size(alpha_j_D, 2)
    reim_j_D(:, j) = pj(j) * ( dc2im_j_duim_j_D(:, j) .* duim_j_dt_D(:, j) - alpha_j_D(j)*(c2m_D - c2im_j_D(:, j)) ); 
end 
reim_total_D = zeros(size(t, 2), 1);
for j = 1:size(alpha_j_D, 2)
    reim_total_D = reim_total_D + reim_j_D(:, j);
end
reim_total = reim_total_D / t_c; 

% ------------------------- r_mixing ------------------------- 
ddc2m_ddum_D = 2*K./(um_D.^2+4*K).^(3/2);
rem_mixing = - ddc2m_ddum_D .* ( dum_dx_D/L_c) .* ( dum_dx_D/L_c); 
% ------------------------- r_mass_transfer ------------------------- 
int_duim_j_dt_D = ( sum(alpha_j_D.*pj) * um_D  + euler_inversion(@(s)  u ./s * exp(x_D/2) .* exp(-x_D/2*sqrt(1+4*s.*(1+eta.* sum( alpha_j_D .* pj ./ (s + alpha_j_D) ))))  .*  sum(- alpha_j_D .* alpha_j_D .* pj ./ (s + alpha_j_D)), t_D) ); 
rem_mass_transfer_D = - (eta) * ( dc2m_dum_D .* int_duim_j_dt_D ) ; 
for j = 1:size(alpha_j_D, 2)
    rem_mass_transfer_D  = rem_mass_transfer_D + (eta) * (pj(j) * dc2im_j_duim_j_D(:, j) .* duim_j_dt_D(:, j));
end 
rem_mass_transfer = rem_mass_transfer_D / t_c; 
re_total = rem_mixing + rem_mass_transfer;
% ------------------------- r_m ------------------------- 
rem_total = re_total - (eta) * reim_total; 

figure; 
semilogx(t, um_D, 'Linewidth', 4); 
hold on; 
load('um_simulated.mat'); 
semilogx(t(10:10:10000), um_simulated, 'o', 'markersize', 10, 'Linewidth', 3);
semilogx(t, sum_uim_j_D, 'Linewidth', 4);
load('uim_simulated.mat'); 
semilogx(t(10:10:10000), uim_simulated, 'o', 'markersize', 10, 'Linewidth', 3);
xlim([10^(0) 10^(3)])
set(gca, 'Linewidth', 1, 'Fontweight', 'bold', 'Fontsize', 28);
legend('u_{m} (analytical)', 'u_{m} (numerical)', 'u_{im} (analytical)', 'u_{im} (numerical)');
xlabel('t');
ylabel('u');

figure; 
semilogx(t, -rem_total, 'Linewidth', 4); 
hold on; 
load('rem_simulated.mat'); 
semilogx(t(10:10:10000), -rem_simulated, 'o', 'markersize', 10, 'Linewidth', 3);
semilogx(t, -reim_total, 'Linewidth', 4); 
load('reim_simulated.mat');
semilogx(t(10:10:10000), -reim_simulated, 'o', 'markersize', 10, 'Linewidth', 3);
xlim([10^(0) 10^(3)])
set(gca, 'Linewidth', 2, 'Fontweight', 'bold', 'Fontsize', 28);
legend('r_{e}_{m} (analytical)', 'r_{e}_{m} (numerical)', 'r_{e}_{im} (analytical)', 'r_{e}_{im} (numerical)');
xlabel('t');
ylabel('-r_{e}'); 

