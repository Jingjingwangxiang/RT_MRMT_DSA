close all; clc; clear all; 

set(0, 'defaultfigurecolor', 'w');

num_immobile = [1 3 10 30 50 70 100];
CPU_time = [27.8438 19.6875; 55.0312 37.4375; 128.1562 159.5156; 374.8438 1784.2812; 627.6562 6839.7656; 874.9688 17025.1406; 1288.5938 43353.8906];

num_immobile = [3 10 30 50 70 100];
CPU_time = [55.0312 37.4375; 128.1562 159.5156; 374.8438 1784.2812; 627.6562 6839.7656; 874.9688 17025.1406; 1288.5938 43353.8906];

xx = [1:100];
yy1 = interp1(num_immobile, CPU_time(:, 1), xx,'spline'); 
yy2 = interp1(num_immobile, CPU_time(:, 2), xx,'spline'); 

figure; 
bar(num_immobile, CPU_time); 
hold on; 
plot(xx, yy1, 'linewidth', 2); 
plot(xx, yy2, 'linewidth', 2, 'color', [0.47 0.67 0.19]);
text (18, 370, '\itO(N)', 'Fontweight', 'bold', 'Fontsize', 18 ); 
text (36, 10000, '\itO(N^{3})', 'Fontweight', 'bold', 'Fontsize', 18 ); 
set(gca,'xscale','log','yscale','log',  'Linewidth', 2, 'Fontweight', 'bold', 'Fontsize', 18);
legend('Proposed method', 'Full DSA', 'location', 'Northwest');
xlabel('Number of immobile zones');
ylabel('Log CPU time [s]'); 
